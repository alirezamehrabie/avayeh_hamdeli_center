import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import path from 'path'; // Import path

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/sass/app.scss', // Change this
                'resources/js/app.js',
            ],
            refresh: true,
        }),
    ],
    resolve: { // Add this section
        alias: {
            '~bootstrap': path.resolve(__dirname, 'node_modules/bootstrap'),
        }
    },
});
